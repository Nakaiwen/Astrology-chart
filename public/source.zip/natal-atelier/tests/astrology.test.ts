import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { SwissEphemeris } from '@swisseph/browser';
import { calculateWithEngine, DEFAULT_INPUT, resolveTime, houseOf, normalize, formatPosition, zodiac } from '../lib/astrology.ts';

const swe=new SwissEphemeris();
await swe.init('data:application/wasm;base64,'+readFileSync('node_modules/@swisseph/browser/dist/swisseph.wasm').toString('base64'));
let count=0;
function check(name:string,fn:()=>void){fn();count++;console.log('PASS '+name);}
const chart=calculateWithEngine(swe,DEFAULT_INPUT);
check('Synthetic Taipei example UTC and Julian day',()=>{assert.equal(chart.metadata.utc,'2000-01-01T04:00:00.000Z');assert.equal(chart.metadata.utc_offset,'+08:00');assert.ok(Math.abs(chart.metadata.julian_day-2451544.6666666665)<1e-8);});
check('11 celestial positions against independent Python Swiss Ephemeris output',()=>{
 const expected=[280.029114108,219.308095749,271.370815944,241.162848008,327.704757022,25.239630941,40.402388671,314.792466687,303.181136565,251.442977326,123.970470659];
 const houses=[9,7,9,8,11,1,1,11,10,8,4];
 chart.chart_data.placements.forEach((p,i)=>{assert.ok(Math.abs(p.absolute_degree-expected[i])<.000002,p.body);assert.equal(p.house,houses[i],p.body);});
 assert.equal(chart.chart_data.placements[6].motion,'retrograde');
});
check('Placidus house cusps and axes',()=>{const expected=[15.790586989,49.788329453,76.556815112,100.692166348,126.211339880,157.116800279,195.790586989,229.788329453,256.556815112,280.692166348,306.211339880,337.116800279];chart.chart_data.house_cusps!.forEach((p,i)=>assert.ok(Math.abs(p.absolute_degree-expected[i])<.000002));assert.ok(Math.abs(chart.chart_data.ascendant!.absolute_degree-15.790586989)<.000002);assert.ok(Math.abs(chart.chart_data.midheaven!.absolute_degree-280.692166348)<.000002);});
check('Day and night sect keep morning Mercury on the day side',()=>{assert.equal(chart.chart_data.sect.status,'day');assert.deepEqual(chart.chart_data.sect.sect_mate_planets,['Jupiter','Saturn','Mercury']);assert.equal(chart.chart_data.mercury_sect!.status,'day');assert.equal(chart.chart_data.mercury_sect!.solar_phase,'morning');assert.deepEqual(chart.chart_data.placements[2].rules_houses,[3,6]);assert.ok(Math.abs(chart.chart_data.lots![0].absolute_degree-normalize(15.790586989+219.308095749-280.029114108))<.000002);const night=calculateWithEngine(swe,{...DEFAULT_INPUT,time:'21:00'});assert.equal(night.chart_data.sect.status,'night');assert.deepEqual(night.chart_data.sect.sect_mate_planets,['Venus','Mars']);assert.equal(night.chart_data.mercury_sect!.status,'day');assert.ok(Math.abs(night.chart_data.lots![0].absolute_degree-normalize(night.chart_data.ascendant!.absolute_degree+night.chart_data.placements[0].absolute_degree-night.chart_data.placements[1].absolute_degree))<.000002);});
check('Unknown birth time omits inferred axes, houses, rulers, lots and sect',()=>{const c=calculateWithEngine(swe,{...DEFAULT_INPUT,unknownTime:true});assert.equal(c.metadata.local_time,null);assert.equal(c.metadata.reference_time,'12:00');for(const k of ['house_cusps','house_rulers','ascendant','midheaven','lots','mercury_sect'])assert.ok(!(k in c.chart_data));assert.ok(c.chart_data.placements.every(p=>p.house===undefined&&p.rules_houses===undefined));assert.equal(c.chart_data.sect.status,'unknown');assert.ok(c.chart_data.aspects.filter(a=>[a.body_a,a.body_b].includes('Moon')).every(a=>a.notes?.includes('不確定')));});
check('Whole Sign and Equal systems use expected cusps',()=>{const w=calculateWithEngine(swe,{...DEFAULT_INPUT,houseSystem:'Whole Sign'});assert.equal(w.chart_data.house_cusps![0].absolute_degree,0);assert.equal(w.chart_data.ascendant!.absolute_degree,chart.chart_data.ascendant!.absolute_degree);assert.equal(w.chart_data.placements[1].house,8);const e=calculateWithEngine(swe,{...DEFAULT_INPUT,houseSystem:'Equal'});e.chart_data.house_cusps!.forEach((c,i)=>assert.ok(Math.abs(c.absolute_degree-normalize(chart.chart_data.ascendant!.absolute_degree+30*i))<.000002));});
check('Historical Taiwan daylight saving is applied',()=>assert.equal(resolveTime({...DEFAULT_INPUT,date:'1979-07-01'}).offset,'+09:00'));
check('Nonexistent and duplicated DST timestamps are rejected by default',()=>{const b={...DEFAULT_INPUT,timezone:'America/New_York'};assert.throws(()=>resolveTime({...b,date:'2024-03-10',time:'02:30'}));assert.throws(()=>resolveTime({...b,date:'2024-03-10',time:'02:30',disambiguation:'later'}));assert.throws(()=>resolveTime({...b,date:'2024-11-03',time:'01:30'}));const a=resolveTime({...b,date:'2024-11-03',time:'01:30',disambiguation:'earlier'}),z=resolveTime({...b,date:'2024-11-03',time:'01:30',disambiguation:'later'});assert.equal(z.date.getTime()-a.date.getTime(),3600000);assert.equal(a.offset,'-04:00');assert.equal(z.offset,'-05:00');});
check('Bad coordinates, dates, timezone and high-latitude Placidus rejected',()=>{for(const patch of [{latitude:'NaN'},{latitude:''},{longitude:'181'},{date:'1899-12-31'},{date:'2024-02-30'},{timezone:'Not/AZone'},{latitude:'67'}])assert.throws(()=>calculateWithEngine(swe,{...DEFAULT_INPUT,...patch}));assert.ok(calculateWithEngine(swe,{...DEFAULT_INPUT,latitude:'67',houseSystem:'Whole Sign'}).chart_data.ascendant);});
check('House boundaries include their own cusp, including 360° wrap',()=>{const c=chart.chart_data.house_cusps!.map(c=>c.absolute_degree);c.forEach((v,i)=>assert.equal(houseOf(v,c),i+1));assert.equal(formatPosition(zodiac(359.9999)),'牡羊座 0°00′');});
check('Aspect motion is consistent with next minute of planetary positions',()=>{for(const a of chart.chart_data.aspects){if(a.applying===undefined||a.exact)continue;const names=['Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','True Node'];const ids=[names.indexOf(a.body_a),names.indexOf(a.body_b)];const values=ids.map(i=>swe.calculatePosition(chart.metadata.julian_day+1/1440,i===10?11:i,260).longitude);const sep=Math.abs(((values[0]-values[1]+540)%360)-180),angle=({conjunction:0,sextile:60,square:90,trine:120,opposition:180} as Record<string,number>)[a.aspect];assert.equal(Math.abs(sep-angle)<a.orb_degrees,a.applying,`${a.body_a} ${a.aspect} ${a.body_b}`);}});
if(process.env.CHART_TEST_OUTPUT)writeFileSync(process.env.CHART_TEST_OUTPUT,JSON.stringify(chart,null,2));
swe.close();console.log(`${count} checks passed.`);

const { formFromExport } = await import('../lib/astrology.ts');
check('formFromExport restores the form from natal, transit and bundle exports', () => {
  const restored = formFromExport(JSON.parse(JSON.stringify(chart)));
  assert.equal(restored.date, DEFAULT_INPUT.date); assert.equal(restored.time, DEFAULT_INPUT.time);
  assert.equal(restored.unknownTime, false); assert.equal(restored.timezone, DEFAULT_INPUT.timezone);
  assert.equal(restored.latitude, DEFAULT_INPUT.latitude); assert.equal(restored.houseSystem, 'Placidus');
  assert.equal(restored.orb, 'focused'); assert.equal(restored.question, DEFAULT_INPUT.question);
  const transit = { reading_type: 'transit', tradition_mode: chart.tradition_mode, chart_data: chart.chart_data, natal_metadata: chart.metadata, user_question: '請白話解讀這段月運的主要生活主題與可行建議。' };
  assert.equal(formFromExport(transit).date, DEFAULT_INPUT.date);
  assert.equal(formFromExport(transit).question, DEFAULT_INPUT.question);
  const bundle = { reading_type: 'year_bundle', natal: chart };
  assert.equal(formFromExport(bundle).place, DEFAULT_INPUT.place);
  const unknown = calculateWithEngine(swe, { ...DEFAULT_INPUT, unknownTime: true });
  assert.equal(formFromExport(JSON.parse(JSON.stringify(unknown))).unknownTime, true);
  for (const bad of [null, 42, {}, { reading_type: 'natal' }, { reading_type: 'transit', chart_data: chart.chart_data }]) assert.throws(() => formFromExport(bad));
});

const { fileSlug } = await import('../lib/astrology.ts');
check('fileSlug keeps CJK, strips path characters, never empty', () => {
  assert.equal(fileSlug('Nakai'), 'Nakai');
  assert.equal(fileSlug('示範星盤'), '示範星盤');
  assert.equal(fileSlug('  a/b\\c:d*e?f"g<h>i|j. '), 'abcdefghij');
  assert.equal(fileSlug('   '), '星盤');
  assert.equal(fileSlug('小 六 太 乙'), '小_六_太_乙');
});
